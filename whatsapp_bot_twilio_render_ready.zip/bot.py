from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

@app.route("/whatsapp", methods=["POST"])
def reply_whatsapp():
    mensaje = request.form.get('Body')
    respuesta = MessagingResponse()
    
    if "hola" in mensaje.lower():
        respuesta.message("¡Hola! Soy un robot 🤖. ¿Cómo estás?")
    else:
        respuesta.message("Lo siento, no entendí 😕. Di 'hola'.")

    return str(respuesta)

app.run(port=5000)
